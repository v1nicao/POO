package FabricaAbstrata.src;

public class TesteEmpresaOnibusUrbano {

}
